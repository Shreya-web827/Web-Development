const yes = document.querySelector("#yes");
const no = document.querySelector("#no");
 yes.style.fontSize = "2rem";

no.addEventListener("click", () => {
    // yes.style.fontSize = "6rem";
    let currentSize = parseFloat(yes.style.fontSize);
    yes.style.fontSize = (currentSize +1) + "rem";
});

no.addEventListener("dblclick", () => {
    document.querySelector("#img").style.display = "block";
    setTimeout(() => {
        document.querySelector("#img").style.display = "none";
    }, 2000);
});

yes.addEventListener("click", () =>{ 
    document.querySelector("#thnks").style.display = "block";
});